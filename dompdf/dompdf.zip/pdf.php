<!DOCTYPE html>
<html>
<head>
    <meta char="UTF-8">
    <title>Form Pendaftaran <b><i>Semarak Anak Shalih</i></b></title>
    <link rel="stylesheet" href="style/mystyle.css">    
</head>
<body>
    <p>Helloo whats App</p>
</body>
</html>










 